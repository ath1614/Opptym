chrome.runtime.onInstalled.addListener(() => {
    console.log('🧩 SEO Autofill Extension Installed');
  });
  