# 🤖 AI-Powered SEO Autofill Extension

## Overview
This Chrome extension automatically detects and fills form fields on any website using AI-powered form analysis. No more manual field mapping required!

## Features

### 🧠 AI-Powered Form Detection
- **Automatic Field Mapping**: Uses AI to analyze form structure and map fields to your project data
- **Multiple AI Providers**: Supports Hugging Face (free), OpenAI, and local Ollama
- **Smart Fallbacks**: Falls back to pattern-based detection if AI fails
- **Confidence Scoring**: Shows how confident the AI is in its field mappings

### 🔧 How It Works
1. **Login** to your SEO automation account
2. **Select a project** with your business data
3. **Navigate** to any directory submission website
4. **Click "Smart Autofill"** - the extension will:
   - Analyze the form structure using AI
   - Map fields to your project data
   - Automatically fill the form
   - Show confidence level and results

### 🎯 Supported Field Types
- **Contact Info**: Name, email, phone
- **Business Info**: Company name, address, website
- **Content**: Descriptions, keywords, meta data
- **Location**: City, state, country, postal code

## Setup

### 1. Install Extension
1. Download the extension ZIP from your SEO automation dashboard
2. Unzip the folder
3. Open Chrome and go to `chrome://extensions/`
4. Enable "Developer mode"
5. Click "Load unpacked" and select the extension folder

### 2. Configure AI (Optional)
- **Free Option**: Uses Hugging Face Inference API (no setup required)
- **Paid Option**: Add your OpenAI API key in the admin panel
- **Local Option**: Install Ollama for local AI processing

### 3. Use the Extension
1. Click the extension icon in your browser
2. Login with your account credentials
3. Select a project from your dashboard
4. Navigate to any form and click "Smart Autofill"

## Technical Details

### AI Analysis Process
1. **Form Extraction**: Extracts HTML structure and field information
2. **AI Analysis**: Sends form data to AI service for field mapping
3. **DOM Enhancement**: Combines AI results with DOM-based detection
4. **Smart Filling**: Applies mappings and fills form fields

### Supported AI Providers
- **Hugging Face**: Free tier, good for basic form analysis
- **OpenAI**: Paid, more accurate and comprehensive
- **Ollama**: Local, privacy-focused, requires local installation

### Fallback Detection
If AI analysis fails, the extension uses pattern-based detection:
- Common field name patterns (`email`, `phone`, `business`)
- Input type detection (`type="email"`)
- Label text analysis
- Placeholder text matching

## Benefits

### 🚀 Efficiency
- **No Manual Mapping**: Works on any website without pre-configuration
- **Faster Submissions**: Reduces form filling time by 80-90%
- **Scalable**: Handle hundreds of directory submissions easily

### 🎯 Accuracy
- **AI-Powered**: Learns from form patterns and improves over time
- **Smart Detection**: Understands context and field relationships
- **Confidence Scoring**: Know how reliable the mapping is

### 💰 Cost-Effective
- **Free AI Option**: Use Hugging Face for no additional cost
- **Reduced Manual Work**: Save hours of manual form mapping
- **Higher Success Rate**: More accurate submissions mean better results

## Troubleshooting

### Common Issues
1. **"Analysis failed"**: Check your internet connection and AI API settings
2. **"Fields not found"**: The form might use unusual field names
3. **"Low confidence"**: AI couldn't reliably map fields, using fallback

### Solutions
- Try refreshing the page and running autofill again
- Check the browser console for detailed error messages
- Verify your AI API key is correct in the admin panel
- Use the fallback method if AI analysis consistently fails

## Support
For technical support or feature requests, contact your system administrator or check the main application's support documentation. 