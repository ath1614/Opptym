document.addEventListener('DOMContentLoaded', () => {
  console.log('[Popup] Loaded');

  const axiosInstance = window.axios;
  const API_BASE = 'http://localhost:5050/api';
  const loginSection = document.getElementById('loginSection');
  const loginForm = document.getElementById('loginForm');
  const projectSection = document.getElementById('projectSection');
  const projectSelect = document.getElementById('projectSelect');
  const autofillBtn = document.getElementById('autofillBtn');
  const analysisStatus = document.getElementById('analysisStatus');
  const analysisText = document.getElementById('analysisText');
  const confidenceText = document.getElementById('confidenceText');

  // Session check (1-day expiry)
  const ts = parseInt(localStorage.getItem('loginTimestamp') || '0', 10);
  if (ts && Date.now() - ts < 86400000) {
    showProjects();
  }

  // Handle login
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    const password = e.target.password.value;

    try {
      const res = await axiosInstance.post(
        `${API_BASE}/auth/login`,
        { email, password },
        { headers: { 'Content-Type': 'application/json' }, withCredentials: true }
      );

      localStorage.setItem('token', res.data.token);
      localStorage.setItem('loginTimestamp', Date.now().toString());
      showProjects();

    } catch (err) {
      alert('❌ Login failed.');
      console.error(err);
    }
  });

  // Fetch and display projects
  async function showProjects() {
    loginSection.style.display = 'none';
    projectSection.style.display = 'block';

    const token = localStorage.getItem('token');
    try {
      const res = await axiosInstance.get(
        `${API_BASE}/projects`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      projectSelect.innerHTML = '<option value="">-- Select project --</option>';
      res.data.forEach(project => {
        const opt = document.createElement('option');
        opt.value = JSON.stringify(project);
        opt.textContent = project.title;
        projectSelect.appendChild(opt);
      });

    } catch (err) {
      alert('⚠️ Error loading projects.');
      console.error(err);
    }
  }

  // Enable autofill only when project is selected
  projectSelect.addEventListener('change', () => {
    autofillBtn.disabled = !projectSelect.value;
  });

  // AI-Powered Smart Autofill
  autofillBtn.addEventListener('click', async () => {
    const project = JSON.parse(projectSelect.value);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Show analysis status
    analysisStatus.style.display = 'block';
    analysisText.textContent = '🔍 Analyzing form structure with AI...';
    confidenceText.textContent = '';
    autofillBtn.disabled = true;

    try {
      // First, analyze the form structure
      const formAnalysis = await analyzeFormStructure(tab.id, project);
      
      // Show confidence level
      const confidencePercent = Math.round(formAnalysis.confidence * 100);
      analysisText.textContent = `✅ Form analysis complete!`;
      confidenceText.textContent = `Confidence: ${confidencePercent}% | Fields mapped: ${Object.keys(formAnalysis.fieldMappings).length}`;
      
      // Then apply the smart mappings
      await applySmartAutofill(tab.id, project, formAnalysis);
    } catch (error) {
      analysisText.textContent = '❌ Analysis failed, using fallback...';
      confidenceText.textContent = 'Using enhanced pattern detection';
      
      // Fallback to enhanced method
      await applyFallbackAutofill(tab.id, project);
    } finally {
      autofillBtn.disabled = false;
      // Hide status after 5 seconds
      setTimeout(() => {
        analysisStatus.style.display = 'none';
      }, 5000);
    }
  });

  // Add a debug button for field inspection
  const debugBtn = document.createElement('button');
  debugBtn.textContent = '🔍 Debug Fields';
  debugBtn.style.cssText = 'margin-top: 10px; padding: 8px; background: #f0f0f0; border: 1px solid #ccc; border-radius: 4px; font-size: 12px; cursor: pointer;';
  debugBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const allInputs = document.querySelectorAll('input, textarea, select');
        const fieldInfo = Array.from(allInputs).map((input, index) => ({
          index,
          tag: input.tagName,
          name: input.name || 'no-name',
          id: input.id || 'no-id',
          placeholder: input.placeholder || 'no-placeholder',
          type: input.type || 'no-type',
          className: input.className || 'no-class',
          value: input.value || 'empty'
        }));
        
        console.log('[DEBUG] All form fields found:', fieldInfo);
        
        // Create a visual overlay showing field details
        const overlay = document.createElement('div');
        overlay.style.cssText = `
          position: fixed;
          top: 10px;
          right: 10px;
          width: 400px;
          max-height: 80vh;
          background: white;
          border: 2px solid #007bff;
          border-radius: 8px;
          padding: 15px;
          z-index: 10000;
          overflow-y: auto;
          font-family: monospace;
          font-size: 12px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        
        overlay.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <h3 style="margin: 0; color: #007bff;">🔍 Field Inspector</h3>
            <button onclick="this.parentElement.parentElement.remove()" style="background: #dc3545; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer;">✕</button>
          </div>
          <div style="margin-bottom: 10px; padding: 8px; background: #f8f9fa; border-radius: 4px;">
            <strong>Total Fields Found: ${fieldInfo.length}</strong>
          </div>
          ${fieldInfo.map((field, i) => `
            <div style="margin-bottom: 8px; padding: 8px; border: 1px solid #ddd; border-radius: 4px; background: ${i % 2 === 0 ? '#f8f9fa' : 'white'};">
              <div style="font-weight: bold; color: #007bff;">Field ${i + 1}</div>
              <div><strong>Tag:</strong> ${field.tag}</div>
              <div><strong>Name:</strong> ${field.name}</div>
              <div><strong>ID:</strong> ${field.id}</div>
              <div><strong>Type:</strong> ${field.type}</div>
              <div><strong>Placeholder:</strong> ${field.placeholder}</div>
              <div><strong>Class:</strong> ${field.className}</div>
            </div>
          `).join('')}
        `;
        
        document.body.appendChild(overlay);
        
        // Also highlight fields on the page
        fieldInfo.forEach((field, index) => {
          const element = document.querySelector(`input[name="${field.name}"]`) || 
                         document.querySelector(`input[id="${field.id}"]`) ||
                         document.querySelectorAll('input, textarea, select')[index];
          
          if (element) {
            element.style.border = '2px solid #007bff';
            element.style.backgroundColor = '#e3f2fd';
            element.title = `Field ${index + 1}: ${field.tag} | name="${field.name}" | id="${field.id}" | type="${field.type}"`;
          }
        });
        
        alert(`🔍 Debug mode activated! Found ${fieldInfo.length} fields. Check the overlay and console for details.`);
      }
    });
    
    document.body.appendChild(debugBtn);
  });

  // Analyze form structure using AI
  async function analyzeFormStructure(tabId, project) {
    try {
      const formData = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          // Extract form HTML and field information
          const forms = document.querySelectorAll('form');
          const formInfo = [];
          
          forms.forEach((form, formIndex) => {
            const inputs = form.querySelectorAll('input, textarea, select');
            const fields = [];
            
            inputs.forEach((input, inputIndex) => {
              const field = {
                selector: generateSelector(input),
                type: input.type || input.tagName.toLowerCase(),
                name: input.name || '',
                id: input.id || '',
                placeholder: input.placeholder || '',
                label: findLabel(input),
                required: input.required || false,
                value: input.value || '',
                formIndex,
                inputIndex
              };
              fields.push(field);
            });
            
            formInfo.push({
              formIndex,
              action: form.action || '',
              method: form.method || 'get',
              fields
            });
          });
          
          return {
            url: window.location.href,
            title: document.title,
            forms: formInfo,
            formHTML: document.body.innerHTML
          };
          
          function generateSelector(element) {
            if (element.id) return `#${element.id}`;
            if (element.name) return `${element.tagName.toLowerCase()}[name="${element.name}"]`;
            if (element.className) return `${element.tagName.toLowerCase()}.${element.className.split(' ')[0]}`;
            return `${element.tagName.toLowerCase()}:nth-child(${Array.from(element.parentNode.children).indexOf(element) + 1})`;
          }
          
          function findLabel(input) {
            if (input.id) {
              const label = document.querySelector(`label[for="${input.id}"]`);
              if (label) return label.textContent.trim();
            }
            
            const parent = input.parentElement;
            const label = parent.querySelector('label');
            if (label) return label.textContent.trim();
            
            return '';
          }
        }
      });

      const formInfo = formData[0].result;
      
      // Call backend AI service for form analysis
      const token = localStorage.getItem('token');
      const analysisResponse = await axiosInstance.post(
        `${API_BASE}/form-analysis/analyze`,
        {
          formInfo,
          project
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      return analysisResponse.data;
    } catch (error) {
      console.error('Form analysis failed:', error);
      // Fallback to common patterns
      return getFallbackMappings();
    }
  }

  // Apply smart autofill based on AI analysis
  async function applySmartAutofill(tabId, project, formAnalysis) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: (project, fieldMappings) => {
          console.log('[Smart Autofill] Starting with AI mappings:', fieldMappings);
          
          let filledCount = 0;
          let totalFields = Object.keys(fieldMappings).length;
          
          Object.entries(fieldMappings).forEach(([selector, projectField]) => {
            const element = document.querySelector(selector);
            if (element) {
              const value = getProjectValue(project, projectField);
              if (value) {
                element.focus();
                element.value = value;
                element.dispatchEvent(new Event('input', { bubbles: true }));
                element.dispatchEvent(new Event('change', { bubbles: true }));
                filledCount++;
                console.log(`[Smart Autofill] Filled ${selector} with ${projectField}: ${value}`);
              }
            } else {
              console.warn(`[Smart Autofill] Field not found: ${selector}`);
            }
          });
          
          // Show results
          const message = `✅ Smart autofill complete!\nFilled ${filledCount}/${totalFields} fields using AI detection.`;
          alert(message);
          
          function getProjectValue(project, fieldPath) {
            const paths = fieldPath.split('.');
            let value = project;
            
            for (const path of paths) {
              if (value && typeof value === 'object' && path in value) {
                value = value[path];
              } else {
                return null;
              }
            }
            
            return value || '';
          }
        },
        args: [project, formAnalysis.fieldMappings || {}]
      });
    } catch (error) {
      console.error('Smart autofill failed:', error);
      alert('❌ Autofill failed. Trying fallback method...');
      
      // Fallback to original method
      await applyFallbackAutofill(tabId, project);
    }
  }

  // Fallback autofill method (original hardcoded mappings)
  async function applyFallbackAutofill(tabId, project) {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (project) => {
        console.log('[Ultimate Autofill] Starting comprehensive field detection and filling');
        
        // Ultimate field detection function
        function findFieldByPattern(patterns, value) {
          for (const pattern of patterns) {
            const elements = document.querySelectorAll(pattern);
            for (const element of elements) {
              if (element && (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA' || element.tagName === 'SELECT')) {
                return element;
              }
            }
          }
          return null;
        }

        // Ultimate field filling function that works on ANY website
        function ultimateFillField(element, value) {
          if (!element || !value) return false;
          
          try {
            console.log(`[Ultimate Autofill] Filling field:`, element.tagName, element.name, element.id, 'with value:', value);
            
            // Method 1: Direct value assignment
            element.value = value;
            
            // Method 2: Focus and simulate typing
            element.focus();
            element.select();
            element.setRangeText(value);
            
            // Method 3: Trigger all possible events
            const events = ['input', 'change', 'blur', 'focus', 'keyup', 'keydown', 'keypress', 'paste', 'cut'];
            events.forEach(eventType => {
              element.dispatchEvent(new Event(eventType, { bubbles: true, cancelable: true }));
              element.dispatchEvent(new InputEvent(eventType, { bubbles: true }));
            });
            
            // Method 4: React/Angular/Vue specific handling
            if (element._valueTracker) {
              element._valueTracker.setValue(value);
            }
            
            // Method 5: Custom property setting
            element.setAttribute('value', value);
            element.setAttribute('data-value', value);
            
            // Method 6: Force re-render
            element.style.display = 'none';
            element.offsetHeight; // Force reflow
            element.style.display = '';
            
            // Method 7: Trigger custom events
            element.dispatchEvent(new CustomEvent('autofill', { 
              detail: { value }, 
              bubbles: true 
            }));
            
            // Method 8: Handle different input types
            if (element.type === 'email') {
              element.setAttribute('type', 'text');
              element.value = value;
              element.setAttribute('type', 'email');
            }
            
            // Method 9: Handle contenteditable elements
            if (element.contentEditable === 'true') {
              element.textContent = value;
              element.innerHTML = value;
            }
            
            // Method 10: Handle shadow DOM
            if (element.shadowRoot) {
              const shadowInputs = element.shadowRoot.querySelectorAll('input, textarea');
              shadowInputs.forEach(input => {
                input.value = value;
                input.dispatchEvent(new Event('input', { bubbles: true }));
              });
            }
            
            // Visual feedback
            element.style.backgroundColor = '#e8f5e8';
            element.style.borderColor = '#28a745';
            element.style.boxShadow = '0 0 0 2px rgba(40, 167, 69, 0.25)';
            
            // Remove visual feedback after 3 seconds
            setTimeout(() => {
              element.style.backgroundColor = '';
              element.style.borderColor = '';
              element.style.boxShadow = '';
            }, 3000);
            
            return true;
          } catch (error) {
            console.error('Error filling field:', error);
            return false;
          }
        }

        // Comprehensive field patterns for ANY website
        const fieldPatterns = {
          firstName: [
            'input[name*="first"]', 'input[id*="first"]', 'input[placeholder*="first"]',
            'input[name*="fname"]', 'input[id*="fname"]', 'input[placeholder*="fname"]',
            'input[name*="given"]', 'input[id*="given"]', 'input[placeholder*="given"]',
            'input[name*="forename"]', 'input[id*="forename"]', 'input[placeholder*="forename"]',
            'input[data-field*="first"]', 'input[data-name*="first"]',
            'input[aria-label*="first"]', 'input[title*="first"]'
          ],
          lastName: [
            'input[name*="last"]', 'input[id*="last"]', 'input[placeholder*="last"]',
            'input[name*="lname"]', 'input[id*="lname"]', 'input[placeholder*="lname"]',
            'input[name*="surname"]', 'input[id*="surname"]', 'input[placeholder*="surname"]',
            'input[name*="family"]', 'input[id*="family"]', 'input[placeholder*="family"]',
            'input[data-field*="last"]', 'input[data-name*="last"]',
            'input[aria-label*="last"]', 'input[title*="last"]'
          ],
          fullName: [
            'input[name*="full"]', 'input[name*="name"]', 'input[id*="name"]', 'input[placeholder*="name"]',
            'input[name*="contact"]', 'input[id*="contact"]', 'input[placeholder*="contact"]',
            'input[name*="person"]', 'input[id*="person"]', 'input[placeholder*="person"]',
            'input[data-field*="name"]', 'input[data-name*="name"]',
            'input[aria-label*="name"]', 'input[title*="name"]',
            'input[type="text"]'
          ],
          businessName: [
            'input[name*="business"]', 'input[name*="company"]', 'input[name*="organization"]',
            'input[id*="business"]', 'input[id*="company"]', 'input[id*="organization"]',
            'input[placeholder*="business"]', 'input[placeholder*="company"]', 'input[placeholder*="organization"]',
            'input[name*="firm"]', 'input[id*="firm"]', 'input[placeholder*="firm"]',
            'input[name*="enterprise"]', 'input[id*="enterprise"]', 'input[placeholder*="enterprise"]',
            'input[data-field*="business"]', 'input[data-name*="business"]',
            'input[aria-label*="business"]', 'input[title*="business"]'
          ],
          email: [
            'input[type="email"]', 'input[name*="email"]', 'input[id*="email"]', 'input[placeholder*="email"]',
            'input[name*="e-mail"]', 'input[id*="e-mail"]', 'input[placeholder*="e-mail"]',
            'input[name*="mail"]', 'input[id*="mail"]', 'input[placeholder*="mail"]',
            'input[data-field*="email"]', 'input[data-name*="email"]',
            'input[aria-label*="email"]', 'input[title*="email"]'
          ],
          phone: [
            'input[name*="phone"]', 'input[name*="tel"]', 'input[name*="telephone"]', 'input[name*="mobile"]',
            'input[id*="phone"]', 'input[id*="tel"]', 'input[id*="telephone"]', 'input[id*="mobile"]',
            'input[placeholder*="phone"]', 'input[placeholder*="tel"]', 'input[placeholder*="telephone"]', 'input[placeholder*="mobile"]',
            'input[type="tel"]', 'input[type="phone"]',
            'input[data-field*="phone"]', 'input[data-name*="phone"]',
            'input[aria-label*="phone"]', 'input[title*="phone"]'
          ],
          address: [
            'input[name*="address"]', 'input[name*="street"]', 'input[name*="location"]',
            'input[id*="address"]', 'input[id*="street"]', 'input[id*="location"]',
            'input[placeholder*="address"]', 'input[placeholder*="street"]', 'input[placeholder*="location"]',
            'textarea[name*="address"]', 'textarea[id*="address"]', 'textarea[placeholder*="address"]',
            'input[data-field*="address"]', 'input[data-name*="address"]',
            'input[aria-label*="address"]', 'input[title*="address"]'
          ],
          city: [
            'input[name*="city"]', 'input[name*="town"]', 'input[name*="municipality"]',
            'input[id*="city"]', 'input[id*="town"]', 'input[id*="municipality"]',
            'input[placeholder*="city"]', 'input[placeholder*="town"]', 'input[placeholder*="municipality"]',
            'input[data-field*="city"]', 'input[data-name*="city"]',
            'input[aria-label*="city"]', 'input[title*="city"]'
          ],
          state: [
            'input[name*="state"]', 'input[name*="province"]', 'input[name*="region"]',
            'input[id*="state"]', 'input[id*="province"]', 'input[id*="region"]',
            'input[placeholder*="state"]', 'input[placeholder*="province"]', 'input[placeholder*="region"]',
            'select[name*="state"]', 'select[id*="state"]',
            'input[data-field*="state"]', 'input[data-name*="state"]',
            'input[aria-label*="state"]', 'input[title*="state"]'
          ],
          zip: [
            'input[name*="zip"]', 'input[name*="postal"]', 'input[name*="pincode"]', 'input[name*="code"]',
            'input[id*="zip"]', 'input[id*="postal"]', 'input[id*="pincode"]', 'input[id*="code"]',
            'input[placeholder*="zip"]', 'input[placeholder*="postal"]', 'input[placeholder*="pincode"]', 'input[placeholder*="code"]',
            'input[data-field*="zip"]', 'input[data-name*="zip"]',
            'input[aria-label*="zip"]', 'input[title*="zip"]'
          ],
          country: [
            'input[name*="country"]', 'input[name*="nation"]',
            'input[id*="country"]', 'input[id*="nation"]',
            'input[placeholder*="country"]', 'input[placeholder*="nation"]',
            'select[name*="country"]', 'select[id*="country"]',
            'input[data-field*="country"]', 'input[data-name*="country"]',
            'input[aria-label*="country"]', 'input[title*="country"]'
          ],
          description: [
            'textarea[name*="description"]', 'textarea[name*="about"]', 'textarea[name*="details"]',
            'textarea[id*="description"]', 'textarea[id*="about"]', 'textarea[id*="details"]',
            'textarea[placeholder*="description"]', 'textarea[placeholder*="about"]', 'textarea[placeholder*="details"]',
            'textarea[name*="content"]', 'textarea[name*="message"]', 'textarea[name*="comment"]',
            'textarea[data-field*="description"]', 'textarea[data-name*="description"]',
            'textarea[aria-label*="description"]', 'textarea[title*="description"]',
            'div[contenteditable="true"]', 'div[data-field*="description"]'
          ],
          website: [
            'input[name*="website"]', 'input[name*="url"]', 'input[name*="site"]', 'input[name*="web"]',
            'input[id*="website"]', 'input[id*="url"]', 'input[id*="site"]', 'input[id*="web"]',
            'input[placeholder*="website"]', 'input[placeholder*="url"]', 'input[placeholder*="site"]', 'input[placeholder*="web"]',
            'input[type="url"]',
            'input[data-field*="website"]', 'input[data-name*="website"]',
            'input[aria-label*="website"]', 'input[title*="website"]'
          ]
        };

        // Fill fields with project data
        let filledCount = 0;
        const filledFields = [];
        const filledElements = [];

        // Fill first name
        const firstNameField = findFieldByPattern(fieldPatterns.firstName, project.contactName?.first);
        if (firstNameField && project.contactName?.first) {
          if (ultimateFillField(firstNameField, project.contactName.first)) {
            filledCount++;
            filledFields.push('First Name');
            filledElements.push(firstNameField);
          }
        }

        // Fill last name
        const lastNameField = findFieldByPattern(fieldPatterns.lastName, project.contactName?.last);
        if (lastNameField && project.contactName?.last) {
          if (ultimateFillField(lastNameField, project.contactName.last)) {
            filledCount++;
            filledFields.push('Last Name');
            filledElements.push(lastNameField);
          }
        }

        // Fill full name (if no separate first/last fields found)
        if (!firstNameField && !lastNameField) {
          const fullNameField = findFieldByPattern(fieldPatterns.fullName, project.name);
          if (fullNameField && project.name) {
            if (ultimateFillField(fullNameField, project.name)) {
              filledCount++;
              filledFields.push('Full Name');
              filledElements.push(fullNameField);
            }
          }
        }

        // Fill business name
        const businessField = findFieldByPattern(fieldPatterns.businessName, project.businessName);
        if (businessField && project.businessName) {
          if (ultimateFillField(businessField, project.businessName)) {
            filledCount++;
            filledFields.push('Business Name');
            filledElements.push(businessField);
          }
        }

        // Fill email
        const emailField = findFieldByPattern(fieldPatterns.email, project.email);
        if (emailField && project.email) {
          if (ultimateFillField(emailField, project.email)) {
            filledCount++;
            filledFields.push('Email');
            filledElements.push(emailField);
          }
        }

        // Fill phone
        const phoneField = findFieldByPattern(fieldPatterns.phone, project.phone);
        if (phoneField && project.phone) {
          if (ultimateFillField(phoneField, project.phone)) {
            filledCount++;
            filledFields.push('Phone');
            filledElements.push(phoneField);
          }
        }

        // Fill address
        const addressField = findFieldByPattern(fieldPatterns.address, project.address);
        if (addressField && project.address) {
          if (ultimateFillField(addressField, project.address)) {
            filledCount++;
            filledFields.push('Address');
            filledElements.push(addressField);
          }
        }

        // Fill city
        const cityField = findFieldByPattern(fieldPatterns.city, project.city);
        if (cityField && project.city) {
          if (ultimateFillField(cityField, project.city)) {
            filledCount++;
            filledFields.push('City');
            filledElements.push(cityField);
          }
        }

        // Fill state
        const stateField = findFieldByPattern(fieldPatterns.state, project.state);
        if (stateField && project.state) {
          if (ultimateFillField(stateField, project.state)) {
            filledCount++;
            filledFields.push('State');
            filledElements.push(stateField);
          }
        }

        // Fill zip
        const zipField = findFieldByPattern(fieldPatterns.zip, project.pincode);
        if (zipField && project.pincode) {
          if (ultimateFillField(zipField, project.pincode)) {
            filledCount++;
            filledFields.push('Zip');
            filledElements.push(zipField);
          }
        }

        // Fill country
        const countryField = findFieldByPattern(fieldPatterns.country, project.country);
        if (countryField && project.country) {
          if (ultimateFillField(countryField, project.country)) {
            filledCount++;
            filledFields.push('Country');
            filledElements.push(countryField);
          }
        }

        // Fill description
        const descField = findFieldByPattern(fieldPatterns.description, project.metaDescription);
        if (descField && project.metaDescription) {
          if (ultimateFillField(descField, project.metaDescription)) {
            filledCount++;
            filledFields.push('Description');
            filledElements.push(descField);
          }
        }

        // Fill website
        const websiteField = findFieldByPattern(fieldPatterns.website, project.url);
        if (websiteField && project.url) {
          if (ultimateFillField(websiteField, project.url)) {
            filledCount++;
            filledFields.push('Website');
            filledElements.push(websiteField);
          }
        }

        // Ultimate fallback: Fill any remaining empty fields by type and position
        if (filledCount < 5) {
          console.log('[Ultimate Autofill] Trying ultimate fallback method...');
          
          const allInputs = Array.from(document.querySelectorAll('input, textarea, select'));
          const emptyInputs = allInputs.filter(input => 
            !input.value && 
            input.type !== 'submit' && 
            input.type !== 'button' && 
            input.type !== 'hidden' &&
            !filledElements.includes(input)
          );
          
          console.log(`[Ultimate Autofill] Found ${emptyInputs.length} empty inputs for fallback`);
          
          // Fill remaining empty fields based on their type and position
          emptyInputs.forEach((input, index) => {
            if (input.type === 'email' && project.email && !document.querySelector('input[value="' + project.email + '"]')) {
              if (ultimateFillField(input, project.email)) {
                filledCount++;
                filledFields.push('Email (fallback)');
              }
            } else if (input.type === 'tel' && project.phone && !document.querySelector('input[value="' + project.phone + '"]')) {
              if (ultimateFillField(input, project.phone)) {
                filledCount++;
                filledFields.push('Phone (fallback)');
              }
            } else if (input.type === 'text' && index === 0 && project.contactName?.first) {
              if (ultimateFillField(input, project.contactName.first)) {
                filledCount++;
                filledFields.push('First Name (fallback)');
              }
            } else if (input.type === 'text' && index === 1 && project.contactName?.last) {
              if (ultimateFillField(input, project.contactName.last)) {
                filledCount++;
                filledFields.push('Last Name (fallback)');
              }
            } else if (input.type === 'text' && index === 2 && project.businessName) {
              if (ultimateFillField(input, project.businessName)) {
                filledCount++;
                filledFields.push('Business (fallback)');
              }
            } else if (input.tagName === 'TEXTAREA' && project.metaDescription) {
              if (ultimateFillField(input, project.metaDescription)) {
                filledCount++;
                filledFields.push('Description (fallback)');
              }
            }
          });
        }

        // Force a page refresh to ensure all changes are visible
        setTimeout(() => {
          // Trigger any remaining form validation
          filledElements.forEach(element => {
            element.dispatchEvent(new Event('blur', { bubbles: true }));
          });
          
          // Force any framework-specific updates
          if (window.angular) {
            window.angular.element(document.body).scope().$apply();
          }
          if (window.Vue) {
            // Vue components might need manual updates
            document.querySelectorAll('[data-v-]').forEach(el => {
              el.dispatchEvent(new Event('input', { bubbles: true }));
            });
          }
        }, 100);

        console.log(`[Ultimate Autofill] Filled ${filledCount} fields:`, filledFields);
        alert(`✅ Ultimate autofill complete! Filled ${filledCount} fields: ${filledFields.join(', ')}`);
        
        // Additional debug info
        console.log('[Ultimate Autofill] Project data used:', {
          firstName: project.contactName?.first,
          lastName: project.contactName?.last,
          businessName: project.businessName,
          email: project.email,
          phone: project.phone,
          address: project.address,
          city: project.city,
          state: project.state,
          pincode: project.pincode,
          country: project.country,
          description: project.metaDescription,
          website: project.url
        });
        
        // Debug: Show all form fields found on the page
        if (filledCount === 0) {
          const allInputs = document.querySelectorAll('input, textarea, select');
          const fieldInfo = Array.from(allInputs).map(input => ({
            tag: input.tagName,
            name: input.name || 'no-name',
            id: input.id || 'no-id',
            placeholder: input.placeholder || 'no-placeholder',
            type: input.type || 'no-type'
          }));
          console.log('[Debug] All form fields found:', fieldInfo);
          alert(`🔍 Debug: Found ${fieldInfo.length} form fields. Check console for details.`);
        }
      },
      args: [project]
    });
  }

  // Get fallback mappings for common patterns
  function getFallbackMappings() {
    return {
      fieldMappings: {
        // Name fields - multiple patterns
        'input[name*="first"]': 'contactName.first',
        'input[name*="last"]': 'contactName.last',
        'input[name*="full"]': 'name',
        'input[name*="name"]': 'name',
        'input[name*="contact"]': 'name',
        'input[id*="first"]': 'contactName.first',
        'input[id*="last"]': 'contactName.last',
        'input[id*="name"]': 'name',
        'input[placeholder*="first"]': 'contactName.first',
        'input[placeholder*="last"]': 'contactName.last',
        'input[placeholder*="name"]': 'name',
        
        // Business fields
        'input[name*="business"]': 'businessName',
        'input[name*="company"]': 'businessName',
        'input[name*="organization"]': 'businessName',
        'input[name*="firm"]': 'businessName',
        'input[id*="business"]': 'businessName',
        'input[id*="company"]': 'businessName',
        'input[placeholder*="business"]': 'businessName',
        'input[placeholder*="company"]': 'businessName',
        
        // Contact fields
        'input[type="email"]': 'email',
        'input[name*="email"]': 'email',
        'input[name*="e-mail"]': 'email',
        'input[id*="email"]': 'email',
        'input[placeholder*="email"]': 'email',
        'input[name*="phone"]': 'phone',
        'input[name*="telephone"]': 'phone',
        'input[name*="mobile"]': 'phone',
        'input[name*="tel"]': 'phone',
        'input[id*="phone"]': 'email',
        'input[id*="tel"]': 'phone',
        'input[placeholder*="phone"]': 'phone',
        'input[placeholder*="tel"]': 'phone',
        
        // Address fields
        'input[name*="address"]': 'address',
        'input[name*="street"]': 'address',
        'input[name*="location"]': 'address',
        'input[id*="address"]': 'address',
        'input[placeholder*="address"]': 'address',
        'input[name*="city"]': 'city',
        'input[name*="town"]': 'city',
        'input[id*="city"]': 'city',
        'input[placeholder*="city"]': 'city',
        'input[name*="state"]': 'state',
        'input[name*="province"]': 'state',
        'input[id*="state"]': 'state',
        'input[placeholder*="state"]': 'state',
        'input[name*="zip"]': 'pincode',
        'input[name*="postal"]': 'pincode',
        'input[name*="pincode"]': 'pincode',
        'input[id*="zip"]': 'pincode',
        'input[id*="postal"]': 'pincode',
        'input[placeholder*="zip"]': 'pincode',
        'input[placeholder*="postal"]': 'pincode',
        'input[name*="country"]': 'country',
        'input[id*="country"]': 'country',
        'input[placeholder*="country"]': 'country',
        
        // Description fields
        'textarea[name*="description"]': 'metaDescription',
        'textarea[name*="about"]': 'metaDescription',
        'textarea[name*="details"]': 'metaDescription',
        'textarea[name*="content"]': 'metaDescription',
        'textarea[name*="message"]': 'metaDescription',
        'textarea[id*="description"]': 'metaDescription',
        'textarea[id*="about"]': 'metaDescription',
        'textarea[placeholder*="description"]': 'metaDescription',
        'textarea[placeholder*="about"]': 'metaDescription',
        
        // Website fields
        'input[name*="website"]': 'url',
        'input[name*="url"]': 'url',
        'input[name*="site"]': 'url',
        'input[name*="web"]': 'url',
        'input[id*="website"]': 'url',
        'input[id*="url"]': 'url',
        'input[placeholder*="website"]': 'url',
        'input[placeholder*="url"]': 'url',
        
        // Common form field IDs (WordPress, etc.)
        '#wpforms-3791-field_0': 'contactName.first',
        '#wpforms-3791-field_3': 'businessName',
        '#wpforms-3791-field_5': 'address',
        '#wpforms-3791-field_1': 'email',
        '#wpforms-3791-field_4': 'phone',
        '#wpforms-3791-field_2': 'metaDescription',
        
        // Generic field patterns
        'input[type="text"]': 'name',
        'textarea': 'metaDescription'
      },
      confidence: 0.4,
      detectedFields: []
    };
  }
});
  